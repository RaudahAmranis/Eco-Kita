import 'package:flutter/material.dart';
import 'frontpg1.dart'; // 导入 Group36Widget

class Group34Widget extends StatefulWidget {
  @override
  _Group34WidgetState createState() => _Group34WidgetState();
}

class _Group34WidgetState extends State<Group34Widget> {
  double _opacity = 0.0; // 初始化透明度为 0（完全透明）

  @override
  void initState() {
    super.initState();

    // 自动跳转到下一个页面（Group36Widget）
    Future.delayed(Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => Group36Widget()),
      );
    });

    // 1 秒后启动淡入效果
    Future.delayed(Duration(seconds: 1), () {
      setState(() {
        _opacity = 1.0; // 完全不透明
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          _buildAnimatedImage(
            'lib/assets/images/p1pic1.png',
            widthFactor: 1.0,
            heightFactor: 0.35,
            topFactor: 0.30,
            leftFactor: 0.0,
          ),
        ],
      ),
    );
  }

  // 构建带淡入淡出效果的图片组件
  Widget _buildAnimatedImage(
      String assetPath, {
        required double widthFactor,
        required double heightFactor,
        double topFactor = 0.0,
        double leftFactor = 0.0,
      }) {
    return Positioned(
      top: topFactor * MediaQuery.of(context).size.height,
      left: leftFactor * MediaQuery.of(context).size.width,
      child: AnimatedOpacity(
        duration: Duration(seconds: 1), // 动画时长 3 秒
        opacity: _opacity, // 动态透明度
        child: Container(
          width: widthFactor * MediaQuery.of(context).size.width,
          height: heightFactor * MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(assetPath),
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
    );
  }
}
