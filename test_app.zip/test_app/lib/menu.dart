import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Compact7Widget extends StatelessWidget {
  final List<String> imagePaths = [
    'lib/assets/images/25874413_71664081.png',
    'lib/assets/images/25874413_71664081.png',
    'lib/assets/images/25874413_71664081.png'
  ];
  final List<String> urls = [
    'https://chatgpt.com/c/67213dc6-9cb4-8012-9bff-58b1ce17bd22',
    'https://console.cloud.google.com/freetrial/signup/tos?redirectPath=%2Fgoogle%2Fmaps-apis%2Fonboard;flow%3Djust-ask-flow;step%3Djust_ask&project=fleet-blend-440211-d3',
    'https://cloud.google.com/translate/?utm_source=bing&utm_medium=cpc&utm_campaign=japac-MY-all-en-dr-bkws-all-all-trial-e-dr-1009882&utm_content=text-ad-none-none-DEV_c-CRE_-ADGP_Hybrid+%7C+BKWS+-+EXA+%7C+Txt+~+AI+%26+ML+~+Translation+AI_Translation-API-KWID_43700071934463576-kwd-74835780549240:loc-112&userloc_150751-network_o&utm_term=KW_google%20map%20api%20key&gclid=7224766e5df31021e5e5114c473ae492&gclsrc=3p.ds&'
  ];

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(screenWidth * 0.15),
            color: Colors.white,
          ),
          child: Stack(
            children: <Widget>[
              _buildTopLogo(screenWidth, screenHeight),
              _buildLargeCircle(screenWidth, screenHeight),
              // 添加可切换的图片组件
              Positioned(
                top: screenHeight * 0.55,  // 这里调整图片顶部位置
                left: screenWidth * 0.05,
                right: screenWidth * 0.05,
                child: Container(
                  height: screenHeight * 0.3,
                  child: PageView.builder(
                    itemCount: imagePaths.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () async {
                          final url = urls[index];
                          if (await canLaunch(url)) {
                            await launch(url);
                          } else {
                            throw 'Could not launch $url';
                          }
                        },
                        child: Container( // 这里包裹容器以便更改位置
                          alignment: Alignment.center, // 可以调整对齐方式
                          child: Image.asset(
                            imagePaths[index],
                            fit: BoxFit.cover,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
              // 保留其余的原始组件
              _buildText('HI RAUDAH', screenHeight * 0.2, screenWidth * 0.05,
                  screenWidth * 0.05, FontWeight.normal, 1),
              _buildText('Let’s contribute to our Earth', screenHeight * 0.25,
                  screenWidth * 0.05, screenWidth * 0.04, FontWeight.normal, 1),
              _buildRoundedBox(screenHeight * 0.3, screenWidth * 0.05,
                  screenWidth * 0.8, screenHeight * 0.25, 0.59),
              _buildRoundedBox(screenHeight * 0.8, screenWidth * -0.2,
                  screenWidth * 1.2, screenHeight * 0.25, 0.59),
              _buildImageContainer(screenHeight * 0.9, screenWidth * 0.25,
                  screenWidth * 0.4, screenHeight * 0.2, 'lib/assets/images/Back1.png'),
              _buildSmallBox(screenHeight * 0.6, screenWidth * 0.05,
                  screenWidth * 0.4, screenHeight * 0.1, Colors.white),
              _buildFeatureItem(
                screenHeight * 0.7,
                screenWidth * 0.07,
                'lib/assets/images/Carsharing_71786341.png',
              ),
              _buildFeatureItem(
                screenHeight * 0.7,
                screenWidth * 0.51,
                'lib/assets/images/Trash_25737471.png',
              ),
              _buildBottomBar(screenWidth, screenHeight),
            ],
          ),
        ),
      ),
    );
  }
}

Positioned _buildTopLogo(double screenWidth, double screenHeight) {
    return Positioned(
      top: -0.07 * screenHeight,
      left: screenWidth * 0.3,
      child: Container(
        width: screenWidth * 0.5,
        height: screenHeight * 0.25,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('lib/assets/images/menupic1.png'),
            fit: BoxFit.fitWidth,
          ),
        ),
      ),
    );
  }

  Positioned _buildLargeCircle(double screenWidth, double screenHeight) {
    return Positioned(
      top: screenHeight * 0.5,
      left: screenWidth * -0.25,
      child: Container(
        width: screenWidth * 1.6,
        height: screenWidth * 1.6,
        decoration: BoxDecoration(
          color: Color.fromRGBO(14, 23, 36, 1),
          shape: BoxShape.circle,
        ),
      ),
    );
  }

  Positioned _rotatedImage(double angle, double left, double top, double width,
      double height, String path) {
    return Positioned(
      top: top,
      left: left,
      child: Transform.rotate(
        angle: angle * (math.pi / 180),
        child: Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(path),
              fit: BoxFit.fitWidth,
            ),
          ),
        ),
      ),
    );
  }

  Positioned _buildText(String text, double top, double left, double fontSize,
      FontWeight fontWeight, double height) {
    return Positioned(
      top: top,
      left: left,
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: Color.fromRGBO(0, 55, 34, 0.96),
          fontFamily: 'Inter',
          fontSize: fontSize,
          fontWeight: fontWeight,
          height: height,
        ),
      ),
    );
  }

  Positioned _buildRoundedBox(double top, double left, double width,
      double height, double opacity) {
    return Positioned(
      top: 220,
      left: 12,
      child: Container(
        width: 335,
        height: 235,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(60),
          color: Color.fromRGBO(0, 99, 0, 1),
        ),
      ),
    );
  }

  Positioned _buildImageContainer(double top, double left, double width,
      double height, String path) {
    return Positioned(
      top: top,
      left: left,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(40),
          image: DecorationImage(
            image: AssetImage(path),
            fit: BoxFit.fitWidth,
          ),
        ),
      ),
    );
  }

  Positioned _buildSmallBox(double top, double left, double width, double height,
      Color color) {
    return Positioned(
      top: top,
      left: left,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: color,
        ),
      ),
    );
  }

  Positioned _buildFeatureItem(double top, double left, String imagePath) {
    return Positioned(
      top: 270,
      left: left,
      child: Container(
        width: 150,
        height: 120,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: Color.fromRGBO(255, 255, 255, 1),
        ),
        child: Center(
          child: Container(
            width: 102,
            height: 102,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(imagePath),
                fit: BoxFit.fitWidth,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Positioned _buildBottomBar(double screenWidth, double screenHeight) {
    return Positioned(
      top: screenHeight * 0.9,
      left: -screenWidth * 0.1,
      child: Container(
        width: screenWidth * 1.2,
        height: screenHeight * 0.2,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(screenWidth * 0.15),
          color: Color.fromRGBO(38, 136, 14, 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildIconWithLabel('Home', 'lib/assets/images/Homelogo1.png'),
            _buildIconWithLabel('Messages', 'lib/assets/images/Email_73071101.png'),
            _buildIconWithLabel('Activity', 'lib/assets/images/History_39496111.png'),
            _buildIconWithLabel('Account', 'lib/assets/images/User_151942131.png'),
          ],
        ),
      ),
    );
  }

  Column _buildIconWithLabel(String label, String iconPath) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          iconPath,
          width: 50,
          height: 50,
        ),
        SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontFamily: 'Inter',
          ),
        ),
      ],
    );
  }

