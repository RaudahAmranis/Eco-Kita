import 'package:flutter/material.dart';
import 'frontpg.dart'; // 引入 Group34Widget

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Group34Widget(), // 使用 Group34Widget 作为起始页面
    );
  }
}
