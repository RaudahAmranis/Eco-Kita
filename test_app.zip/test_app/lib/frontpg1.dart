import 'package:flutter/material.dart';
import 'signup.dart'; // 引入 signup.dart 文件
import 'signin.dart'; // 引入 signin.dart 文件

class Group36Widget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // 获取屏幕的宽度和高度
    final screenSize = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        width: double.infinity, // 使用无限宽度
        height: double.infinity, // 使用无限高度
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(0),
          color: Color.fromRGBO(255, 255, 255, 1),
        ),
        child: Stack(
          children: <Widget>[
            Positioned(
              top: -0.3 * screenSize.height, // 动态设置位置
              left: -0.26 * screenSize.width,
              child: Container(
                width: screenSize.width * 1.55, // 设置宽度为屏幕宽度的155%
                height: screenSize.height * 0.82, // 设置高度为屏幕高度的82%
                child: Stack(
                  children: <Widget>[
                    Positioned(
                      top: 100,
                      left: 0,
                      child: Container(
                        width: screenSize.width * 1.55,
                        height: screenSize.height * 0.55,
                        decoration: BoxDecoration(
                          color: Color.fromRGBO(14, 23, 36, 1),
                          borderRadius: BorderRadius.circular(627),
                        ),
                      ),
                    ),
                    Positioned(
                      top: screenSize.height * 0.48, // 调整此处以使 PNG 图像与深色格子重叠
                      left: screenSize.width * 0.23,
                      child: Container(
                        width: screenSize.width * 1.05, // 根据屏幕大小设置宽度
                        height: screenSize.height * 0.38, // 根据屏幕大小设置高度
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage('lib/assets/images/p2pic1.png'),
                            fit: BoxFit.fitWidth,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              top: screenSize.height * 0.52, // 相对设置
              left: screenSize.width * 0.20,
              child: Container(
                width: screenSize.width * 0.7, // 根据屏幕大小设置宽度
                height: screenSize.height * 0.25, // 根据屏幕大小设置高度
                child: Stack(
                  children: <Widget>[
                    Positioned(
                      top: screenSize.height * 0.05, // 相对设置
                      left: screenSize.width * 0.03,
                      child: Text(
                        'Welcome to ',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.black,
                          fontFamily: 'Poppins',
                          fontSize: 35,
                          fontWeight: FontWeight.bold,
                          height: 1.2, // 修正行高
                        ),
                      ),
                    ),
                    Positioned(
                      top: -100, // 向上调整 PNG 图像的位置
                      left: -48,
                      child: Container(
                        width: screenSize.width * 0.85,
                        height: screenSize.height * 0.40,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage('lib/assets/images/p2pic2.png'),
                            fit: BoxFit.fitWidth,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // 添加“Get Started”按钮
            Positioned(
              bottom: 30, // 适当调整按钮的位置
              left: screenSize.width * 0.27, // 适当调整按钮的位置
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SignIn()), // 确保 SignIn 已定义
                  );
                },
                child: Text(
                  'Get Started',
                  style: TextStyle(
                    color: Colors.white, // 确保字体为纯白色
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color.fromRGBO(76, 175, 80, 1), // 按钮颜色
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10), // 按钮内边距
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30), // 圆角按钮
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
