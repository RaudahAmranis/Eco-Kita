import 'package:flutter/material.dart';
import 'signup.dart';
import 'menu.dart'; // 导入menu.dart页面

class SignIn extends StatefulWidget {
  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  bool _isPressed = false;
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final screenWidth = screenSize.width;
    final screenHeight = screenSize.height;

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        body: Container(
          width: screenWidth,
          height: screenHeight,
          color: Color.fromRGBO(255, 255, 255, 1),
          child: Stack(
            children: <Widget>[
              Positioned(
                top: -0.3 * screenHeight,
                left: -0.25 * screenWidth,
                child: Container(
                  width: screenWidth * 1.5,
                  height: screenWidth * 1.5,
                  decoration: BoxDecoration(
                    color: Color.fromRGBO(14, 23, 36, 1),
                    borderRadius: BorderRadius.all(
                      Radius.elliptical(screenWidth * 1.5, screenWidth * 1.5),
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 0.45 * screenHeight,
                left: 0.05 * screenWidth,
                child: Container(
                  width: 0.9 * screenWidth,
                  height: 0.37 * screenHeight,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(60),
                    color: Color.fromRGBO(0, 99, 0, 0.93),
                  ),
                ),
              ),
              Positioned(
                top: 0.175 * screenHeight,
                left: 0.05 * screenWidth,
                child: Container(
                  width: 0.9 * screenWidth,
                  height: 0.25 * screenHeight,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('lib/assets/images/p2pic1.png'),
                      fit: BoxFit.fitWidth,
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 0.46 * screenHeight,
                left: 0.37 * screenWidth,
                child: Text(
                  'Sign In',
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Inter',
                    fontSize: screenWidth * 0.08,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Positioned(
                top: 0.53 * screenHeight,
                left: 0.1 * screenWidth,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 0.8 * screenWidth,
                      child: TextField(
                        controller: _emailController,
                        decoration: InputDecoration(
                          labelText: 'Email',
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Container(
                      width: 0.8 * screenWidth,
                      child: TextField(
                        controller: _passwordController,
                        decoration: InputDecoration(
                          labelText: 'Password',
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                        obscureText: true,
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 0.7 * screenHeight,
                left: 0.3 * screenWidth,
                child: GestureDetector(
                  onTap: () {
                    setState(() => _isPressed = true);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Compact7Widget()),
                    );
                  },
                  onTapUp: (_) => setState(() => _isPressed = false),
                  child: Container(
                    width: 0.4 * screenWidth,
                    height: 0.06 * screenHeight,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: _isPressed ? Colors.green[700] : Color.fromRGBO(76, 175, 80, 1),
                    ),
                    child: Center(
                      child: Text(
                        'Sign In',
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Inter',
                          fontSize: screenWidth * 0.05,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 0.77 * screenHeight,
                left: 0.2 * screenWidth,
                child: Text(
                  'Don\'t have an account?',
                  style: TextStyle(
                    color: Color.fromRGBO(230, 230, 230, 1),
                    fontFamily: 'Inter',
                    fontSize: screenWidth * 0.04,
                  ),
                ),
              ),
              Positioned(
                top: 0.77 * screenHeight,
                left: 0.675 * screenWidth,
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SignUp()),
                    );
                  },
                  child: Text(
                    'Sign Up',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: screenWidth * 0.04,
                      fontWeight: FontWeight.normal,
                      decoration: TextDecoration.underline,
                      decorationColor: Colors.white,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
