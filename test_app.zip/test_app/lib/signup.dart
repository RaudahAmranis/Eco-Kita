import 'package:flutter/material.dart';
import 'signin.dart'; // 导入登录页面

class SignUp extends StatefulWidget {
  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  bool _isPressed = false; // 控制按钮按下状态
  Color _signInTextColor = Colors.white; // Sign In 文本颜色

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final screenWidth = screenSize.width;
    final screenHeight = screenSize.height;

    return Scaffold(
      body: Container(
        width: screenWidth,
        height: screenHeight,
        decoration: BoxDecoration(color: Colors.white),
        child: Stack(
          children: <Widget>[
            // 半椭圆形背景
            Positioned(
              top: -0.3 * screenHeight,
              left: -0.25 * screenWidth,
              child: Container(
                width: screenWidth * 1.5,
                height: screenWidth * 1.5,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(14, 23, 36, 1),
                  borderRadius: BorderRadius.circular(screenWidth * 1.5),
                ),
              ),
            ),
            // 绿色背景容器
            Positioned(
              top: 0.45 * screenHeight,
              left: 0.05 * screenWidth,
              child: Container(
                width: 0.9 * screenWidth,
                height: 0.52 * screenHeight,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(60),
                  color: Color.fromRGBO(0, 99, 0, 0.93),
                ),
              ),
            ),
            // 顶部图像
            Positioned(
              top: 0.175 * screenHeight,
              left: 0.05 * screenWidth,
              child: Container(
                width: 0.9 * screenWidth,
                height: 0.25 * screenHeight,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('lib/assets/images/p2pic1.png'),
                    fit: BoxFit.fitWidth,
                  ),
                ),
              ),
            ),
            // Sign Up 标签
            Positioned(
              top: 0.46 * screenHeight,
              left: 0.35 * screenWidth,
              child: Text(
                'Sign Up',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Inter',
                  fontSize: screenWidth * 0.08,
                  fontWeight: FontWeight.bold, // 确保字体为粗体
                ),
              ),
            ),
            // 输入框
            Positioned(
              top: 0.53 * screenHeight,
              left: 0.1 * screenWidth,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Email 输入框
                  _buildInputField('Email', _emailController),
                  SizedBox(height: 10),
                  // Phone 输入框
                  _buildInputField('No. Phone', _phoneController),
                  SizedBox(height: 10),
                  // Password 输入框
                  _buildInputField('Password', _passwordController, obscureText: true),
                  SizedBox(height: 10),
                  // Confirm Password 输入框
                  _buildInputField('Confirm Password', _confirmPasswordController, obscureText: true),
                ],
              ),
            ),
            // 注册按钮
            Positioned(
              top: 0.83 * screenHeight,
              left: 0.3 * screenWidth,
              child: GestureDetector(
                onTap: () {
                  setState(() => _isPressed = true);
                  print('Sign Up pressed');
                },
                onTapUp: (_) => setState(() => _isPressed = false),
                child: AnimatedContainer(
                  duration: Duration(milliseconds: 200),
                  width: 0.4 * screenWidth,
                  height: 0.07 * screenHeight,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    color: _isPressed ? Colors.green[700] : Color.fromRGBO(76, 175, 80, 1),
                  ),
                  child: Center(
                    child: Text(
                      'Sign Up',
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'Inter',
                        fontSize: screenWidth * 0.05,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            // 返回登录按钮
            Positioned(
              top: 0.92 * screenHeight,
              left: 0.2 * screenWidth,
              child: GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => SignIn()),
                  );
                },
                onTapDown: (_) {
                  setState(() => _signInTextColor = Colors.grey[300]!);
                },
                onTapUp: (_) {
                  setState(() => _signInTextColor = Colors.white);
                },
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: 'Already have an account? ',
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Inter',
                          fontSize: screenWidth * 0.04,
                        ),
                      ),
                      TextSpan(
                        text: 'Sign In',
                        style: TextStyle(
                          color: _signInTextColor,
                          fontFamily: 'Inter',
                          fontSize: screenWidth * 0.04,
                          decoration: TextDecoration.underline,
                          decorationColor: Colors.white,
                          decorationThickness: 2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 抽取的输入框构建方法
  Widget _buildInputField(String label, TextEditingController controller, {bool obscureText = false}) {
    return Container(
      width: 0.8 * MediaQuery.of(context).size.width,
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
          filled: true,
          fillColor: Colors.white,
        ),
        obscureText: obscureText,
      ),
    );
  }
}
